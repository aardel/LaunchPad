// Content script - can be used for future features like context menu integration
// Currently minimal

console.log('LaunchIt extension content script loaded');

